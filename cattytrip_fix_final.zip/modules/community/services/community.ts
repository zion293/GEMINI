// Minimal post/comment logic (placeholder)
export type Post = { id: string; title: string; body?: string; createdAt: string; authorId?: string }
export type Comment = { id: string; postId: string; body: string; createdAt: string; authorId?: string }

export function listPosts(): Post[] { return [] }
export function listComments(_: string): Comment[] { return [] }
