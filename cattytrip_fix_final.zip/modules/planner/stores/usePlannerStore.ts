"use client"
import { useState, useCallback } from "react"
import type { Plan } from "@/core/types/plan"

export function usePlannerStore(initial?: Plan) {
  const [plan, setPlan] = useState<Plan | null>(initial ?? null)
  const setTitle = useCallback((title: string) => setPlan(p => p ? { ...p, title } : p), [])
  return { plan, setPlan, setTitle }
}
