// modules/planner/services/scoring.ts
import type { DayPlan } from '@/core/types/plan';
import { estimateEtaMinutes, estimateCrowdFactor, isWithinOpenHours, validateDayConstraints } from './constraints';

export type ScoreWeights = {
  timeFit: number;        // 영업시간 적합도
  travelFriction: number; // 이동 부담(짧을수록 가점)
  crowd: number;          // 혼잡도(낮을수록 가점)
  preference: number;     // 사용자 선호도(있다면)
};

export type DayScoreBreakdown = {
  timeFit: number;        // 0~1
  travelFriction: number; // 0~1
  crowd: number;          // 0~1
  preference: number;     // 0~1
  penalties: { code:string; value:number }[];
  total: number;          // 0~100
};

export const DEFAULT_WEIGHTS: ScoreWeights = {
  timeFit: 0.35,
  travelFriction: 0.30,
  crowd: 0.20,
  preference: 0.15,
};

export function scoreDayPlan(day: DayPlan, weights: ScoreWeights = DEFAULT_WEIGHTS): DayScoreBreakdown {
  const tz = day.timezone || 'Asia/Seoul';

  // 1) 영업시간 적합도
  let timeOk = 1;
  const timePenalties: number[] = [];
  for (const s of day.stops) {
    if (s.openHours) {
      const within = isWithinOpenHours(s.start, s.openHours);
      if (!within.ok) {
        // 60분 이탈마다 -0.1
        const p = Math.min(1, within.minutesOff / 600);
        timePenalties.push(p);
      }
    }
  }
  if (timePenalties.length) timeOk = Math.max(0, 1 - timePenalties.reduce((a,b)=>a+b,0));

  // 2) 이동부담: (체류시간 대비 이동시간 비율) 낮을수록 가점
  let totalStay = 0, totalTravel = 0;
  for (let i=0;i<day.stops.length;i++){
    const st = day.stops[i];
    totalStay += st.durationMinutes;
    const nxt = day.stops[i+1];
    if (nxt) totalTravel += estimateEtaMinutes(st.poi.location, nxt.poi.location, st.travelMode ?? 'TRANSIT');
  }
  const travelRatio = totalTravel / Math.max(1, (totalStay + totalTravel));
  const travelFriction = Math.max(0, 1 - travelRatio); // 이동이 많을수록 낮아짐

  // 3) 혼잡도: 평균 혼잡 1→0 점수
  const crowds = day.stops.map(s => 1 - estimateCrowdFactor(s.poi, s.start, tz));
  const crowdScore = crowds.length ? crowds.reduce((a,b)=>a+b,0)/crowds.length : 1;

  // 4) 선호도: 없으면 0.5
  const prefs = day.stops.map(s => s.preferenceScore ?? 0.5);
  const prefScore = prefs.reduce((a,b)=>a+b,0) / Math.max(1, prefs.length);

  // 이슈 → 페널티
  const { issues } = validateDayConstraints(day);
  const penalties = issues.map(i => ({ code: i.code, value: 0.05 })); // 이슈당 -0.05
  const penaltySum = penalties.reduce((a,b)=>a+b.value,0);

  const blended =
    weights.timeFit * timeOk +
    weights.travelFriction * travelFriction +
    weights.crowd * crowdScore +
    weights.preference * prefScore;

  const final = Math.max(0, blended - penaltySum);
  return {
    timeFit: round2(timeOk),
    travelFriction: round2(travelFriction),
    crowd: round2(crowdScore),
    preference: round2(prefScore),
    penalties,
    total: Math.round(final * 100),
  };
}

function round2(n:number){ return Math.round(n*100)/100; }
