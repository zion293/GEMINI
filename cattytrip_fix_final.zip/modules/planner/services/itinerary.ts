// Pure functions for generating/merging/validating itineraries

import type { Plan, PlanDay } from "@/core/types/plan"

export function generateItinerary(seed: Partial<Plan>): Plan {
  return {
    id: seed.id ?? `tmp-${Date.now()}`,
    title: seed.title ?? "새 여행 계획",
    days: seed.days ?? [],
    ownerId: seed.ownerId,
  }
}

export function mergeItinerary(base: Plan, incoming: Partial<Plan>): Plan {
  return {
    ...base,
    ...incoming,
    days: incoming.days ?? base.days,
  }
}

export function validateItinerary(plan: Plan): { valid: boolean; issues: string[] } {
  const issues: string[] = []
  if (!plan.title?.trim()) issues.push("제목이 비어 있습니다.")
  const dates = new Set<string>()
  plan.days.forEach((d) => {
    if (dates.has(d.date)) issues.push(`중복된 날짜: ${d.date}`)
    dates.add(d.date)
  })
  return { valid: issues.length === 0, issues }
}
