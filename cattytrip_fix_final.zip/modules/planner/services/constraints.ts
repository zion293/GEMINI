// modules/planner/services/constraints.ts
import { DateTime } from 'luxon';
import type { DayPlan, PlanPOI, TransportMode } from '@/core/types/plan';

export type OpenHours = {
  // ISO weekday number 1~7 (Mon~Sun)
  days: number[];
  open: string;  // "HH:mm"
  close: string; // "HH:mm"
  timezone?: string; // e.g., "Asia/Seoul"
};

export type ConstraintIssue =
  | { code: 'CLOSED'; poiId: string; at: string; minutesOff: number }
  | { code: 'TRAVEL_OVERFLOW'; fromId: string; toId: string; needMinutes: number }
  | { code: 'TIGHT_TURNOVER'; poiId: string; gapMinutes: number };

export type ConstraintResult = {
  ok: boolean;
  issues: ConstraintIssue[];
};

const KMPH: Record<TransportMode, number> = {
  WALK: 4.8,
  BIKE: 14,
  CAR: 28,        // 도심 평균치 (신중 보정)
  TRANSIT: 22,    // 환승 포함 평균
};

// 하버사인 + 간단 속도 기반 ETA(분)
export function estimateEtaMinutes(a: {lat:number;lng:number}, b:{lat:number;lng:number}, mode: TransportMode): number {
  const R = 6371; // km
  const toRad = (d:number)=> (d*Math.PI)/180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat), lat2 = toRad(b.lat);
  const h = Math.sin(dLat/2)**2 + Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLng/2)**2;
  const d = 2*R*Math.asin(Math.sqrt(h)); // km
  const kmph = KMPH[mode] ?? 25;
  const hours = d / kmph;
  return Math.max(1, Math.round(hours*60)); // 최소 1분
}

// 시간대(영업시간) 체크
export function isWithinOpenHours(dtISO: string, hours: OpenHours): {ok:boolean; minutesOff:number} {
  const tz = hours.timezone || 'UTC';
  const dt = DateTime.fromISO(dtISO, { zone: tz });
  const dow = dt.weekday; // 1~7
  if (!hours.days.includes(dow)) return { ok:false, minutesOff: 24*60 };
  const open = DateTime.fromFormat(hours.open, 'HH:mm', { zone: tz }).set({ year: dt.year, month: dt.month, day: dt.day });
  let close = DateTime.fromFormat(hours.close, 'HH:mm', { zone: tz }).set({ year: dt.year, month: dt.month, day: dt.day });
  // 익일 넘어가는 영업(예: 23:00~02:00)
  if (close <= open) close = close.plus({ days: 1 });

  if (dt >= open && dt <= close) return { ok:true, minutesOff: 0 };
  const off = dt < open ? open.diff(dt, 'minutes').minutes : dt.diff(close, 'minutes').minutes;
  return { ok:false, minutesOff: Math.abs(Math.round(off)) };
}

// 시간 간격 부족(다음 장소까지 이동 포함) 감지
export function validateDayConstraints(day: DayPlan): ConstraintResult {
  const issues: ConstraintIssue[] = [];
  const tz = day.timezone || 'Asia/Seoul';

  for (let i=0;i<day.stops.length;i++){
    const stop = day.stops[i];
    const start = DateTime.fromISO(stop.start, { zone: tz });
    // 영업시간 체크(옵셔널)
    if (stop.openHours) {
      const within = isWithinOpenHours(stop.start, stop.openHours);
      if (!within.ok) {
        issues.push({ code:'CLOSED', poiId: stop.poi.id, at: stop.start, minutesOff: within.minutesOff });
      }
    }
    // 다음 이동여유 확인
    const end = start.plus({ minutes: stop.durationMinutes });
    const next = day.stops[i+1];
    if (next) {
      const eta = estimateEtaMinutes(stop.poi.location, next.poi.location, stop.travelMode ?? 'TRANSIT');
      const gap = DateTime.fromISO(next.start, {zone:tz}).diff(end, 'minutes').minutes;
      if (gap < eta) {
        issues.push({ code:'TRAVEL_OVERFLOW', fromId: stop.poi.id, toId: next.poi.id, needMinutes: Math.ceil(eta-gap) });
      } else if (gap - eta < 5) {
        issues.push({ code:'TIGHT_TURNOVER', poiId: next.poi.id, gapMinutes: Math.round(gap-eta) });
      }
    }
  }
  return { ok: issues.length===0, issues };
}

// 점심·저녁·주말 혼잡도(0~1). 간단 휴리스틱.
export function estimateCrowdFactor(poi: PlanPOI, atISO: string, regionTz='Asia/Seoul'): number {
  const dt = DateTime.fromISO(atISO, { zone: regionTz });
  const hour = dt.hour;
  const weekend = dt.weekday >= 6;
  let base = 0.2;

  if (poi.category === 'RESTAURANT') {
    if ((hour>=11 && hour<=13) || (hour>=18 && hour<=20)) base = 0.7;
  } else if (poi.category === 'MUSEUM' || poi.category === 'LANDMARK') {
    base = weekend ? 0.6 : 0.4;
    if (hour>=13 && hour<=16) base += 0.1;
  } else if (poi.category === 'SHOPPING') {
    base = weekend ? 0.5 : 0.35;
    if (hour>=17 && hour<=20) base += 0.1;
  }
  // 대중교통/핫스팟 보정(옵션)
  if (poi.popularityScore) base = Math.max(base, Math.min(1, poi.popularityScore));
  return Math.min(1, Math.max(0, base));
}
