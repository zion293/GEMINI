import { createPlan } from '../itinerary';

describe('createPlan', () => {
  it('creates plan with correct day count', async () => {
    const plan = await createPlan({
      title: '서울 2일',
      city: 'Seoul',
      country: 'KR',
      startDate: '2025-08-20',
      endDate: '2025-08-21',
    });
    expect(plan.days.length).toBe(2);
    expect(plan.title).toBe('서울 2일');
  });
});
