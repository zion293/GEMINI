import React from "react"
import type { PlanDay } from "@/core/types/plan"

export default function DayTimeline({ day }: { day: PlanDay }) {
  return (
    <div className="rounded-xl border bg-white p-4 shadow-sm">
      <div className="mb-2 text-sm font-medium">{day.date}</div>
      <ul className="space-y-1 text-sm text-gray-700">
        {day.items.map((it, idx) => (
          <li key={idx}>{it.time ? `[${it.time}] ` : ""}{it.name}</li>
        ))}
      </ul>
    </div>
  )
}
