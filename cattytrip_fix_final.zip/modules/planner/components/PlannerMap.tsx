"use client"
import React, { useEffect, useRef } from "react"
import { loadGoogleMaps } from "@/core/lib/map"

export default function PlannerMap({ height = 300 }: { height?: number }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    loadGoogleMaps().catch(() => {
      // ignore
    })
  }, [])
  return <div ref={ref} className="w-full rounded-xl border bg-gray-100" style={{ height }} />
}
