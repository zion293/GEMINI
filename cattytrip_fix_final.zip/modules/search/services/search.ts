// Keyword/filter search with cache tag (placeholder)
import type { POI } from "@/core/types/plan"
import { tagForPOI } from "@/core/lib/cache"

export type SearchParams = { q: string; lat?: number; lng?: number; radius?: number }

export async function search(params: SearchParams): Promise<{ items: POI[]; tag: string }> {
  const tag = tagForPOI(params.q)
  // TODO: call BFF or external source
  return { items: [], tag }
}
