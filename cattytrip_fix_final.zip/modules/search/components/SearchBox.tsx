"use client"
import React, { useState } from "react"
import { Button } from "@/core/ui/Button"

export default function SearchBox({ onSearch }: { onSearch: (q: string) => void }) {
  const [q, setQ] = useState("")
  return (
    <div className="flex gap-2">
      <input value={q} onChange={e=>setQ(e.target.value)} placeholder="목적지, 키워드" className="w-full rounded-xl border px-3 py-2" />
      <Button onClick={()=>onSearch(q)}>검색</Button>
    </div>
  )
}
