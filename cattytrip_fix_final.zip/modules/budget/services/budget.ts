// Budget aggregation and alerts
export type BudgetCategory = "항공" | "숙소" | "식비" | "교통" | "기타"
export type BudgetItem = { id: string; category: BudgetCategory; amount: number; date?: string; currency?: string }

export function sumByCategory(items: BudgetItem[]) {
  const out: Record<BudgetCategory, number> = { 항공:0, 숙소:0, 식비:0, 교통:0, 기타:0 }
  for (const it of items) out[it.category] += it.amount
  return out
}

export function dailyTotals(items: BudgetItem[]) {
  const out: Record<string, number> = {}
  for (const it of items) {
    const key = it.date ?? "unknown"
    out[key] = (out[key] ?? 0) + it.amount
  }
  return out
}

export function checkLimit(items: BudgetItem[], limit: number) {
  const total = items.reduce((a,b)=>a+b.amount, 0)
  return { total, over: total > limit }
}
