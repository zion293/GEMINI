import React from "react"
import type { BudgetItem } from "@/modules/budget/services/budget"

export default function BudgetTable({ items }: { items: BudgetItem[] }) {
  return (
    <div className="overflow-x-auto rounded-2xl border bg-white shadow-sm">
      <table className="min-w-full text-sm">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-4 py-2 text-left">날짜</th>
            <th className="px-4 py-2 text-left">카테고리</th>
            <th className="px-4 py-2 text-right">금액</th>
          </tr>
        </thead>
        <tbody>
          {items.map(it => (
            <tr key={it.id} className="border-t">
              <td className="px-4 py-2">{it.date ?? "-"}</td>
              <td className="px-4 py-2">{it.category}</td>
              <td className="px-4 py-2 text-right">₩{it.amount.toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
