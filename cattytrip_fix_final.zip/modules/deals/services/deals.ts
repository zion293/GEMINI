// modules/deals/services/deals.ts
import { buildDealTag } from '@/core/cache';
import { normalizeCurrency } from '@/core/lib/money';
import type { DealsQuery, DealItem, DealType } from '@/core/types/deals';

export type DealsProvider = {
  name: string;
  supported: DealType[];
  fetch: (q: DealsQuery) => Promise<DealItem[]>;
};

// --- 예시 프로바이더(실데이터 연결 시 fetch 내부만 교체) ---
const mockFlights: DealsProvider = {
  name: 'mockFlights',
  supported: ['FLIGHT'],
  async fetch(q) {
    const region = q.region ?? 'KR';
    return [
      {
        id: `flight_${region}_1`,
        type: 'FLIGHT',
        title: '서울 ↔ 오사카 왕복',
        region,
        startDate: q.startDate ?? null,
        endDate: q.endDate ?? null,
        price: { amount: 158, currency: 'USD' },
        meta: { airline: 'LCC', fareClass: 'Light' },
        tags: [],
      },
    ];
  },
};

const mockHotels: DealsProvider = {
  name: 'mockHotels',
  supported: ['HOTEL'],
  async fetch(q) {
    const region = q.region ?? 'KR';
    return [
      {
        id: `hotel_${region}_1`,
        type: 'HOTEL',
        title: '난바 비즈니스 호텔 2N',
        region,
        startDate: q.startDate ?? null,
        endDate: q.endDate ?? null,
        price: { amount: 90000, currency: 'KRW' },
        meta: { stars: 3 },
        tags: [],
      },
    ];
  },
};

const providers: DealsProvider[] = [mockFlights, mockHotels];

export async function getDeals(q: DealsQuery, opts?: { baseCurrency?: string }): Promise<DealItem[]> {
  const base = opts?.baseCurrency ?? 'KRW';
  const list: DealItem[] = [];
  for (const p of providers) {
    if (q.types && !q.types.some(t => p.supported.includes(t))) continue;
    const items = await p.fetch(q);
    for (const it of items) {
      const price = normalizeCurrency(it.price, base);
      const tag = buildDealTag(q.region);
      list.push({ ...it, price, tags: [...it.tags, tag] });
    }
  }
  // 간단 정렬: 금액 오름차순
  return list.sort((a,b) => a.price.amount - b.price.amount);
}
