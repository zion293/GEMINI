"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

const items = [
  { href: "/explore", label: "탐색" },
  { href: "/deals", label: "비수기·특가" },
]

export default function PublicNav() {
  const pathname = usePathname()
  return (
    <nav className="flex items-center gap-2 text-sm">
      {items.map(it => {
        const active = pathname === it.href
        return (
          <Link
            key={it.href}
            href={it.href}
            className={`rounded-md px-3 py-1.5 hover:bg-gray-100 ${active ? "bg-gray-900 text-white hover:bg-gray-900" : ""}`}
          >
            {it.label}
          </Link>
        )
      })}
    </nav>
  )
}
