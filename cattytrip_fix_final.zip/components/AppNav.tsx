"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

const items = [
  { href: "/app/dashboard", label: "대시보드" },
  { href: "/app/planner", label: "여행 계획" },
  { href: "/app/budget", label: "예산" },
  { href: "/app/community", label: "커뮤니티" },
]

export default function AppNav() {
  const pathname = usePathname()
  return (
    <nav className="space-y-1 text-sm">
      {items.map(it => {
        const active = pathname === it.href || pathname?.startsWith(it.href + "/")
        return (
          <Link
            key={it.href}
            href={it.href}
            className={`block rounded-md px-3 py-2 hover:bg-gray-100 ${active ? "bg-gray-900 text-white hover:bg-gray-900" : ""}`}
          >
            {it.label}
          </Link>
        )
      })}
    </nav>
  )
}
