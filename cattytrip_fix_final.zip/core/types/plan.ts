export type POI = {
  id: string
  name: string
  location?: { lat: number; lng: number }
  rating?: number
  priceLevel?: number
}

export type PlanItem = {
  time?: string
  name: string
  poiId?: string
}

export type PlanDay = {
  date: string // ISO
  items: PlanItem[]
}

export type Plan = {
  id: string
  title: string
  days: PlanDay[]
  ownerId?: string
}
