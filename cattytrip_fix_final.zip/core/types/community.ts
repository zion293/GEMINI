export interface SharedPlan {
  id: string
  planId: string
  userId: string
  title: string
  description: string
  thumbnail?: string
  likes: number
  bookmarks: number
  views: number
  tags: string[]
  isPublic: boolean
  createdAt: Date
  updatedAt: Date
}

export interface Like {
  id: string
  userId: string
  sharedPlanId: string
  createdAt: Date
}

export interface Bookmark {
  id: string
  userId: string
  sharedPlanId: string
  createdAt: Date
}

export interface Follow {
  id: string
  followerId: string
  followingId: string
  createdAt: Date
}
