export interface User {
  id: string
  email: string
  name: string
  avatar?: string
  level: number
  xp: number
  badges: Badge[]
  preferences: UserPreferences
  createdAt: Date
  updatedAt: Date
}

export interface UserPreferences {
  currency: string
  language: string
  travelStyle: TravelStyle[]
  budgetRange: BudgetRange
  interests: Interest[]
}

export type TravelStyle = "luxury" | "budget" | "adventure" | "cultural" | "relaxation" | "family" | "solo" | "group"

export interface BudgetRange {
  min: number
  max: number
  currency: string
}

export type Interest = "nature" | "history" | "food" | "art" | "nightlife" | "shopping" | "sports" | "photography"

export interface Badge {
  id: string
  name: string
  description: string
  iconUrl: string
  unlockedAt: Date
}
