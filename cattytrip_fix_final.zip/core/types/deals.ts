// core/types/deals.ts
import type { Money } from '@/core/lib/money';

export type DealType = 'FLIGHT'|'HOTEL'|'EVENT';
export type DealsQuery = {
  region?: string;  // "JP-KIX" / "KR-SEL" 등 자유형
  startDate?: string|null;
  endDate?: string|null;
  types?: DealType[];
};
export type DealItem = {
  id: string;
  type: DealType;
  title: string;
  region: string;
  startDate: string|null;
  endDate: string|null;
  price: Money;
  meta?: Record<string, any>;
  tags: string[];
};
