// Server-safe Google Maps helpers (no actual API calls by default)

export type LatLng = { lat: number; lng: number }

/**
 * Server-side placeholder; integrate real Places API here if needed.
 */
export async function searchPlaces(
  query: string,
  location?: LatLng,
  radius?: number,
): Promise<Array<{ id: string; name: string; location?: LatLng; rating?: number; priceLevel?: number }>> {
  // TODO: Wire up to external service; returning empty set for now.
  return []
}

/**
 * Client-side loader for Google Maps JS API. Returns a promise that resolves when window.google is available.
 */
export function loadGoogleMaps(apiKey?: string): Promise<void> {
  if (typeof window === "undefined") return Promise.resolve()
  if ((window as any).google?.maps) return Promise.resolve()

  return new Promise((resolve, reject) => {
    const existing = document.getElementById("google-maps-script") as HTMLScriptElement | null
    if (existing) {
      existing.addEventListener("load", () => resolve())
      existing.addEventListener("error", (e) => reject(e))
      return
    }
    const key = apiKey || process.env.NEXT_PUBLIC_GMAPS_KEY
    if (!key) {
      // Load without key (will fail gracefully), but don't block UI
      resolve()
      return
    }
    const s = document.createElement("script")
    s.id = "google-maps-script"
    s.async = true
    s.src = `https://maps.googleapis.com/maps/api/js?key=${key}&libraries=places`
    s.onload = () => resolve()
    s.onerror = (e) => reject(e)
    document.head.appendChild(s)
  })
}
