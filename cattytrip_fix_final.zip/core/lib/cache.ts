// Simple tag constants and helpers
export const CACHE_TAGS = {
  PLANS: "plans",
  DEALS: "deals",
  POIS: "pois",
} as const

export function tagForPOI(query: string) {
  return `${CACHE_TAGS.POIS}:q:${query}`
}

export function tagForDeals(region?: string) {
  return region ? `${CACHE_TAGS.DEALS}:region:${region}` : CACHE_TAGS.DEALS
}
