// Events/Performances API wrapper (placeholder)
export interface EventsQuery {
  region?: string
  q?: string
  from?: string
  to?: string
}

export interface EventItem {
  id: string
  title: string
  date: string
  venue?: string
  city?: string
}

export async function fetchEvents(_: EventsQuery): Promise<EventItem[]> {
  // TODO: connect to real provider
  return []
}
