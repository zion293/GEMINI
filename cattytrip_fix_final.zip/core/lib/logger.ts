type LogLevel = "info" | "warn" | "error" | "debug"

function fmt(level: LogLevel, msg: string, meta?: Record<string, unknown>, err?: Error) {
  const base = { level, msg, ...meta, ts: new Date().toISOString() }
  if (err) {
    // Avoid exposing stack in production logs by default
    return { ...base, error: { name: err.name, message: err.message } }
  }
  return base
}

export const logger = {
  info(msg: string, meta: Record<string, unknown> = {}) {
    if (process.env.NODE_ENV !== "test") console.log(JSON.stringify(fmt("info", msg, meta)))
  },
  warn(msg: string, meta: Record<string, unknown> = {}) {
    if (process.env.NODE_ENV !== "test") console.warn(JSON.stringify(fmt("warn", msg, meta)))
  },
  error(msg: string, meta: Record<string, unknown> = {}, err?: Error) {
    if (process.env.NODE_ENV !== "test") console.error(JSON.stringify(fmt("error", msg, meta, err)))
  },
  debug(msg: string, meta: Record<string, unknown> = {}) {
    if (process.env.NODE_ENV !== "production") console.debug(JSON.stringify(fmt("debug", msg, meta)))
  },
}
