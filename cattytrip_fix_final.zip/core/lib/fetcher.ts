// core/lib/fetcher.ts
export type ApiOk<T> = { ok:true; data:T };
export type ApiFail = { ok:false; error:string };
export type ApiResponse<T> = ApiOk<T> | ApiFail;

export const ok = <T>(data:T): ApiOk<T> => ({ ok:true, data });
export const fail = (error:string, status=400) => Response.json({ ok:false, error }, { status });
