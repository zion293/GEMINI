// core/lib/inmemory.ts
export const inMemoryPlans = new Map<string, any>();
