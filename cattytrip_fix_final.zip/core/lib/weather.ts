// Weather API wrapper (placeholder)
export interface WeatherRequest {
  lat: number
  lng: number
  date?: string // ISO date
}

export interface WeatherInfo {
  tempC: number
  condition: string
}

export async function fetchWeather(_: WeatherRequest): Promise<WeatherInfo | null> {
  // TODO: connect to real provider
  return null
}
