// core/lib/money.ts
export type Money = { amount: number; currency: string };

const DEFAULT_RATES: Record<string, number> = {
  // 기준: 1 USD = 1300 KRW (환경변수/외부환율로 교체 가능)
  'USD/KRW': Number(process.env.EXCHANGE_USD_KRW ?? 1300),
  'KRW/USD': Number(process.env.EXCHANGE_KRW_USD ?? (1/1300)),
};

export function convert(m: Money, to: string, rates = DEFAULT_RATES): Money {
  if (m.currency === to) return m;
  const key = `${m.currency}/${to}`;
  const rate = rates[key];
  if (!rate) return m; // 환율 모르면 그냥 반환(보수)
  return { amount: Math.round(m.amount * rate), currency: to };
}

export function normalizeCurrency(m: Money, base='KRW'): Money {
  return convert(m, base);
}
