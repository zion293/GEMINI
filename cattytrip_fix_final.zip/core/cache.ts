
export function buildDealTag(region?: string) {
  return region ? `deals:region=${region}` : 'deals';
}
