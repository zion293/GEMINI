import React from "react"

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "destructive"
  size?: "sm" | "md" | "lg"
  loading?: boolean
}

const VARIANT: Record<NonNullable<Props["variant"]>, string> = {
  primary: "bg-gray-900 text-white hover:bg-gray-800",
  secondary: "border hover:bg-gray-50",
  ghost: "hover:bg-gray-100",
  destructive: "bg-red-600 text-white hover:bg-red-500",
}

const SIZE: Record<NonNullable<Props["size"]>, string> = {
  sm: "px-3 py-1.5 text-sm",
  md: "px-4 py-2",
  lg: "px-5 py-3 text-base",
}

export function Button({ variant = "primary", size = "md", loading, className, children, ...rest }: Props) {
  return (
    <button
      className={`inline-flex items-center justify-center rounded-lg ${VARIANT[variant]} ${SIZE[size]} ${className ?? ""}`}
      disabled={loading || rest.disabled}
      {...rest}
    >
      {loading && <span className="mr-2 inline-block h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />}
      {children}
    </button>
  )
}
