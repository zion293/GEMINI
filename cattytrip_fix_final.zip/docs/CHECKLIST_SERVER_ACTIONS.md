# 체크리스트 — 8) 서버 액션/라우트 핸들러

## 서버 액션 — `app/(app)/planner/actions.ts`
- [ ] 낙관적 UI 옵션
- [ ] CSRF/리플레이 방지
- [ ] Idempotency-Key 지원
- [ ] 공통 응답 포맷

## 라우트 핸들러 — `app/api/*`
- [ ] Zod 검증 → 서비스 호출
- [ ] 게스트/회원 식별(guestId 쿠키 vs userId)
- [ ] 캐시 태그 적용 리소스는 revalidate 엔드포인트 제공

**AC:** 프론트 오류 분기 없이 동일 처리 가능.
