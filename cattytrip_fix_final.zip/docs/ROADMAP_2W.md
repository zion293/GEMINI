# ROADMAP (2주)

## Week 1
- [ ] middleware 화이트리스트 + 게스트 플로우 정리(P0)
- [ ] BFF 응답 포맷 통일 + fetcher/logger 도입(P0)
- [ ] deals/search 캐시 태그 적용(P1)

## Week 2
- [ ] planner services(제약/스코어) 1차 구현(P1)
- [ ] types/schemas 중앙화(P1)
- [ ] 유닛/이2이 테스트 기본선 구축(P2)
