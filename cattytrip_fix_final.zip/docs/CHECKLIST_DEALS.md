# 체크리스트 — modules/deals

## services/deals.ts
- [ ] 항공/숙소/이벤트를 공통 Deal 모델로 정규화(가격·통화·기간·지역)
- [ ] 정렬: 웨지 우선(비수기/이벤트) + 할인률 + 개인 성향
- [ ] 캐시태그: `deals`, `deals:region:{code}`
