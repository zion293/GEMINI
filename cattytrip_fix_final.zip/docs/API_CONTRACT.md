# API_CONTRACT — 엔드포인트/DTO/오류 포맷 (요약)

## 공통
- 응답: `{ ok: true, data }` 또는 `{ ok: false, error, code? }`
- 오류코드: 400/401/403/404/422/429/500

## Plans
- GET `/api/plans` → `Plan[]`
- POST `/api/plans` → `Plan` (CreatePlanInput)
- GET `/api/plans/{id}` → `Plan`
- PATCH `/api/plans/{id}` → `Plan(partial)`
- DELETE `/api/plans/{id}` → `{ id, deleted: true }`

## Search/POI
- GET `/api/search/pois?q&lat&lng&radius` → `{ items: POI[] }`

## Deals
- GET `/api/deals` → `DealItem[]`

## Auth(선택)
- GET `/api/auth/callback?code&state` → 302 Redirect
