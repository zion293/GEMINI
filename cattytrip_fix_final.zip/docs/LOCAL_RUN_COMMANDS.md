# LOCAL_RUN_COMMANDS — 로컬 실행/검증 명령

```bash
# 설치
pnpm install

# 개발 서버
pnpm dev

# 타입/린트/테스트
pnpm typecheck
pnpm lint
pnpm test

# E2E
pnpm e2e

# 빌드/프로덕션
pnpm build
pnpm start
```
