# 체크리스트 — modules/community

## services/community.ts
- [ ] 글/댓글 CRUD 최소 로직
- [ ] 품질 점수(신규/중복/링크비율/첫게시 여부)로 노출 지연/경고
- [ ] 첨부(이미지/링크) 정규화
