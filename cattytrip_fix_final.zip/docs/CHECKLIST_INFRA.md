# 체크리스트 — 4) 코어 공통 (Infrastructure)

## core/ui — 디자인 시스템 래핑
**파일:** `core/ui/Button.tsx`, `Card.tsx`, `Modal.tsx`

- [ ] 상태 매트릭스 정의(variant, size, disabled, loading, destructive 등)
- [ ] 접근성(ARIA, focus-visible, ESC/Backdrop close) 보장
- [ ] 아이콘/로딩 스피너 슬롯 규격화
- [ ] 간격/타이포/색상 토큰화(Tailwind 변수)
- [ ] 스냅샷 테스트(주요 변형 3개씩)

**AC(수용 기준):** 동일 상태가 전 페이지에서 시각/행동 일관. 키보드·리더 접근 가능.

---

## core/lib — 공통 라이브러리
**파일:** `fetcher.ts`, `logger.ts`, `cache.ts`, `map.ts`, `weather.ts`, `events.ts`

### fetcher.ts
- [ ] BASE_URL 자동 스위치(상대경로 기본) + 타임아웃/재시도(지수 백오프)
- [ ] 응답 포맷 `{ ok, data | error }` 강제
- [ ] 401/403/429/5xx 재시도·재인증 정책

### logger.ts
- [ ] `info/warn/error/debug` 레벨·포맷 통일
- [ ] PII 마스킹(토큰/쿠키 등)
- [ ] 서버/클라 모두 안전 호출

### cache.ts
- [ ] `unstable_cache`/`revalidateTag` 헬퍼
- [ ] 태그 네이밍 규칙(아래 표준) 적용

### map.ts
- [ ] Google Maps SDK 지연로딩(단 1회) + 오류 처리
- [ ] 키/리퍼러 오류 친절 메시지

### weather.ts / events.ts
- [ ] 외부 API 래핑(레이트리밋·캐시·스키마 정규화)
- [ ] 단위/타임존 변환(기본 Asia/Seoul)

**AC:** 네트워크/캐시/로그 일관 동작, 오류 메시지 표준화.

---

## hooks — 공통 훅
**파일:** `useAuth.ts`, `useQuery.ts(옵션)`

### useAuth.ts
- [ ] 상태: `unauthenticated | guest | authenticated` 구분
- [ ] 세션 리프레시, 초기 로딩/에러 제공
- [ ] 서버 컴포넌트/CSR 안전 경계

### useQuery.ts(선택)
- [ ] 캐시키·stale·retry 옵션
- [ ] fetcher 포맷 연계

**AC:** 게스트/회원 분기 로직이 훅 한 곳에 집약.

---

## middleware.ts
- [ ] 게스트 화이트리스트: `/planner`, `/explore`, `/deals`, `/api/search/*`, `/api/deals`
- [ ] 로캘/UA 추출, A/B 헤더 주입(옵션)
- [ ] 요청·응답 샘플링 로깅(Edge 안전, PII 제거)

**AC:** 프리뷰/로컬에서 미로그인 플로우가 막히지 않음.
