# 체크리스트 — 6) 테스트 (Quality Gate)

## 유닛 — modules/planner/services/tests/*
**파일:** `itinerary.spec.ts`

- [ ] 성공 케이스(정렬/시간블록화)
- [ ] 제약 충돌(영업/이동/날씨 위반 목록)
- [ ] 엣지(빈 일정/중복 장소/불가능 이동)
- [ ] 커버리지 임계치: lines 80%+

## E2E — e2e/*
**파일:** `create-plan.spec.ts`, `share-plan.spec.ts`

- [ ] “검색→생성→저장”(게스트/회원)
- [ ] “공유 보기”(비회원 가능)
- [ ] 리다이렉트 루프 방지 확인

**AC:** CI 브라우저 테스트 안정 통과, flake ≤ 5%.
