# 설치 가이드 (수정 반영)

## 패키지 설치
```bash
npm i
npm i next@14.2.5 react@18.2.0 react-dom@18.2.0
npm i luxon zod next-auth@^4.24.7 jose@^5
npm i -D @playwright/test @types/node
npx playwright install
```

## 스크립트
- Dev: `npm run dev`
- Build: `npm run build`
- Start: `npm run start`
- E2E: `npm run test:e2e` (Playwright가 서버 자동 기동)

## Node/Next 권장 버전
- Node 18 LTS 이상
- Next.js 14.2.5
