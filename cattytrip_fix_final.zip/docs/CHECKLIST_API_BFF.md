# 체크리스트 — 2) API (BFF / Route Handlers)

## plans
- [ ] GET/POST `/api/plans` — 목록/생성(게스트/회원 공통)
- [ ] GET/PATCH/DELETE `/api/plans/[id]` — 단건
- [ ] 응답 포맷 통일 `{ ok, data | error }`
- [ ] 게스트 식별: guestId(쿠키) 또는 임시 토큰

## search/pois
- [ ] 쿼리 검증(q, lat/lng, radius)
- [ ] 외부 API 래핑(키 보안), 캐시 태그 `pois:q:{q}`

## deals
- [ ] 소스 통합 → 표준화, 캐시 태그 `deals(:region)`
- [ ] 재검증 정책(5~30분)

## auth/callback(선택)
- [ ] 코드→토큰→프로필→세션 발급→리다이렉트(직접 구현 시)
- [ ] NextAuth 사용 시 `[...nextauth]` 대체
