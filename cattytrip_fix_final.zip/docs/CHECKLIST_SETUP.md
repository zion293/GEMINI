# 체크리스트 — 7) 설정/환경

## 루트
- [ ] package.json 스크립트: dev/build/start/typecheck/test/lint/e2e/analyze
- [ ] tsconfig paths: `@/*` → 루트 매핑
- [ ] next.config.mjs: 이미지 도메인, headers/rewrites(옵션), 실험 플래그
- [ ] Tailwind/PostCSS/ESLint/Jest/Playwright 설정 최신화
- [ ] components.json(shadcn), pnpm-lock.json 고정
- [ ] .env.example: `GMAPS_KEY`, `WEATHER_KEY`, `EVENTS_KEY`, `NEXTAUTH_SECRET` 등

## DB(선택)
- [ ] prisma/schema.prisma + migrations
- [ ] db/seed.ts

## 문서
- [ ] docs/ARCH_RULES.md — 레이어 의존 규칙
- [ ] docs/GAP_REPORT.md — 설계↔구현 괴리
- [ ] docs/ROADMAP_2W.md — 2주 계획
- [ ] docs/LOCAL_RUN_COMMANDS.md — 실행 명령
- [ ] docs/API_CONTRACT.md — 엔드포인트·DTO·오류 포맷

**AC:** 신규 합류자가 문서만 보고 로컬 기동·스펙 이해 가능.
