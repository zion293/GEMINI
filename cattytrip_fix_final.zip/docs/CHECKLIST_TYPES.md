# 체크리스트 — 5) 타입/검증 (Types/DTO + Zod)

## types/*
**파일:** `plan.ts`, `budget.ts`, `search.ts`, `deals.ts`

- [ ] 도메인 공통 타입 중앙화(Plan/Day/Slot/POI/Deal/BudgetItem/Category)
- [ ] 시간 ISO string, 통화 `code+amount`
- [ ] 불변 모델 지향(가변은 Store/폼 내부로 한정)

**AC:** API/서비스/UI가 동일 타입 소스를 참조.

---

## schemas/*
**파일:** `plan.schema.ts`, `search.schema.ts`, `deals.schema.ts`

- [ ] 입력/출력 스키마 분리
- [ ] `safeParse` 실패 시 422로 일관 처리
- [ ] 좌표/날짜/수치 범위 검증, enum/union 정제
- [ ] DTO↔도메인 변환 함수 제공

**AC:** 잘못된 입력은 항상 `{ ok:false, error, 422 }`.
