# 체크리스트 — modules/search

## services/search.ts
- [ ] 키워드/필터(지역/테마/가격대) → 표준 POI 스키마
- [ ] 캐시 태그키 설계(`pois:q:{q}`), 페이지네이션/정렬 규칙 문서화

## components/SearchBox.tsx
- [ ] 입력 디바운스(300ms), 최근검색/추천 키워드
- [ ] 결과 하이라이트, 키보드 내비게이션
