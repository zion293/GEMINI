# 체크리스트 — modules/budget

## services/budget.ts
- [ ] 합산(카테고리/일자), 한도(전체/카테고리) 경고
- [ ] 환율 변환(통화 코드 기반), 플랜 변경 시 재계산 트리거

## components/BudgetTable.tsx
- [ ] 모바일 카드/데스크탑 테이블 반응형
- [ ] 합계/잔여 배지 고정
