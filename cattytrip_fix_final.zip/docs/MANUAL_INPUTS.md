# 수동 입력/설정이 필요한 항목

## 1) .env.local 값
프로젝트 루트에 `.env.local` 파일 생성:

```
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=REPLACE_WITH_LONG_RANDOM_STRING

# Google OAuth (선택)
GOOGLE_ID=YOUR_GOOGLE_CLIENT_ID
GOOGLE_SECRET=YOUR_GOOGLE_CLIENT_SECRET

# (선택) 환율 고정값 — 실제 환율 API로 대체 가능
EXCHANGE_USD_KRW=1300
EXCHANGE_KRW_USD=0.000769
```

- `NEXTAUTH_SECRET` 는 충분히 긴 랜덤 문자열로 교체하세요.
- Google OAuth를 사용하지 않으면 `Credentials`(guestId)만으로도 동작합니다.

## 2) Playwright
- 최초 1회: `npx playwright install`
- 서버 실행 후 E2E: `npm run test:e2e`

## 3) 외부 데이터 연동
- `modules/deals/services/deals.ts` 의 `providers` 목록에 실제 공급자 커넥터를 추가하고
  `fetch(q)` 내부에서 API 연동 후 `DealItem[]` 형태로 반환하세요.
- 환율은 `core/lib/money.ts` 의 `DEFAULT_RATES` 대신 외부 환율 API를 주입하도록 확장 가능합니다.

## 4) 세션/게스트 머지(선택)
- 로그인 시 `guestId`로 생성된 임시 플랜을 계정 소유로 이전하는 로직을 후속 라운드에 추가합니다.
