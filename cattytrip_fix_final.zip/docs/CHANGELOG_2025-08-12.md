# 변경 내역 (2025-08-12)

## 게스트 플로우/미들웨어
- `middleware.ts`: guestId 자동 발급 + `/app/*` 보호 강화(NextAuth JWT)

## BFF 응답/검증
- `core/lib/fetcher.ts`: `{ ok, data | error }` 포맷 헬퍼 추가
- `/app/api/search/pois/route.ts`: Zod 검증 + 표준 응답 적용
- `/app/api/deals/route.ts`: Zod 검증 + 표준 응답 적용

## 서비스 레이어
- `modules/planner/services/constraints.ts`: ETA/영업시간/혼잡 휴리스틱
- `modules/planner/services/scoring.ts`: 가중치 기반 점수화(0~100)
- `modules/deals/services/deals.ts`: 공급자 구조 + 가격 표준화 + 태그

## 공통 타입/유틸
- `core/types/deals.ts`, `core/lib/money.ts`, `core/lib/inmemory.ts`
- `core/cache.ts`: `buildDealTag()` 추가

## 인증
- `app/api/auth/[...nextauth]/route.ts` + `hooks/useAuth.ts` 기본 결선

## 테스트
- `playwright.config.ts` + `e2e/api.spec.ts`, `e2e/ui.spec.ts` 추가
- `package.json`에 `test:e2e` 스크립트 추가

## 스키마
- `schemas/plan.schema.ts`, `schemas/deals.schema.ts` 갱신
