# 체크리스트 — modules/planner

## services/itinerary.ts
- [ ] 입력: 장소/시간/이동모드/선호
- [ ] 출력: 정렬된 Day/Item + 시간 블록(분단위)
- [ ] 자동 추천 ↔ 사용자 수동수정 충돌 해결 전략 분리

## services/constraints.ts
- [ ] 영업시간/휴무일, 이동시간(모드별 ETA), 날씨(실내/실외 전환)
- [ ] 위반 목록 + 제안 수정안 반환(순서 교체/대체 장소)

## services/scoring.ts
- [ ] 지표: 총이동↓, 백트래킹↓, 인기/혼잡, 선호적합
- [ ] 총점 + 지표별 분해값(설명가능성)

## components
- [ ] PlannerMap.tsx: SDK 로더 분리, dynamic import, once 로딩
- [ ] DayTimeline.tsx: DnD 핸들, 초과시간 경고, 가상 스크롤 고려

## stores/usePlannerStore.ts
- [ ] 편집 로컬 상태만(서버 데이터는 fetch/query)
- [ ] 커밋 시 API 호출(낙관적 업데이트 옵션)
