# ARCH_RULES — 아키텍처 가드레일

- 레이어드:
  - UI(components) ↔ hooks ↔ services(순수) ↔ infra(I/O) ↔ API(Route)
- services는 동기 순수 함수 지향, I/O는 infra로 분리
- 타입/스키마 중앙화: `types/*`, `schemas/*`
- 응답 포맷 통일: `{ ok, data } | { ok:false, error, code? }`
- 캐시 태그 네이밍:
  - `pois:q:{q}`, `deals:region:{code}`, `weather:{lat}:{lng}:{date}`
- 로깅: PII 제거, 레벨·샘플링 기준 준수
- 게스트 정책: 공개 경로/엔드포인트 화이트리스트 명시
