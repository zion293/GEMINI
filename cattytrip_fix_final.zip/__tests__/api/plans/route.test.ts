import { GET, POST } from "@/app/api/plans/route"
import { NextRequest } from "next/server"
import jest from "jest"

// Mock dependencies
jest.mock("@/core/lib/logger")
jest.mock("next/cache", () => ({
  revalidateTag: jest.fn(),
}))

describe("/api/plans", () => {
  describe("GET", () => {
    it("should return plans for valid user", async () => {
      const url = new URL("http://localhost:3000/api/plans?userId=user-1&limit=10&offset=0")
      const request = new NextRequest(url)

      const response = await GET(request)
      const data = await response.json()

      expect(response.status).toBe(200)
      expect(data).toHaveProperty("plans")
      expect(data).toHaveProperty("total")
      expect(data).toHaveProperty("hasMore")
      expect(Array.isArray(data.plans)).toBe(true)
    })

    it("should return 400 for missing userId", async () => {
      const url = new URL("http://localhost:3000/api/plans")
      const request = new NextRequest(url)

      const response = await GET(request)
      const data = await response.json()

      expect(response.status).toBe(400)
      expect(data.error).toBe("User ID is required")
    })
  })

  describe("POST", () => {
    it("should create plan with valid data", async () => {
      const planData = {
        title: "제주도 여행",
        destination: "제주도",
        startDate: "2024-03-15",
        endDate: "2024-03-17",
        budget: 500000,
        participants: 2,
        userId: "user-1",
      }

      const request = new NextRequest("http://localhost:3000/api/plans", {
        method: "POST",
        body: JSON.stringify(planData),
        headers: {
          "Content-Type": "application/json",
        },
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(201)
      expect(data).toHaveProperty("plan")
      expect(data.plan.title).toBe(planData.title)
      expect(data.plan.destination).toBe(planData.destination)
    })

    it("should return 400 for missing required fields", async () => {
      const invalidData = {
        title: "제주도 여행",
        // Missing required fields
      }

      const request = new NextRequest("http://localhost:3000/api/plans", {
        method: "POST",
        body: JSON.stringify(invalidData),
        headers: {
          "Content-Type": "application/json",
        },
      })

      const response = await POST(request)
      const data = await response.json()

      expect(response.status).toBe(400)
      expect(data.error).toBe("Missing required fields")
    })
  })
})
