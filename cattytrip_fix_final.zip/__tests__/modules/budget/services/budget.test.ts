import { BudgetService } from "@/modules/budget/services/budget"
import type { Plan, BudgetItem } from "@/core/types/plan"

describe("BudgetService", () => {
  let service: BudgetService
  let mockPlan: Plan
  let mockBudgetItems: BudgetItem[]

  beforeEach(() => {
    service = new BudgetService()

    mockPlan = {
      id: "plan-1",
      title: "제주도 여행",
      destination: "제주도",
      startDate: new Date("2024-03-15"),
      endDate: new Date("2024-03-17"),
      budget: 500000,
      participants: 2,
      userId: "user-1",
      isPublic: false,
      days: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    mockBudgetItems = [
      {
        id: "budget-1",
        planId: "plan-1",
        category: "accommodation",
        amount: 150000,
        description: "호텔 숙박",
        date: new Date("2024-03-15"),
      },
      {
        id: "budget-2",
        planId: "plan-1",
        category: "food",
        amount: 80000,
        description: "식비",
        date: new Date("2024-03-15"),
      },
      {
        id: "budget-3",
        planId: "plan-1",
        category: "transport",
        amount: 100000,
        description: "항공료",
        date: new Date("2024-03-15"),
      },
    ]
  })

  describe("calculateBudgetSummary", () => {
    it("should calculate correct budget summary", () => {
      const summary = service.calculateBudgetSummary(mockPlan, mockBudgetItems)

      expect(summary.total).toBe(330000)
      expect(summary.remaining).toBe(170000)
      expect(summary.overBudget).toBe(false)
      expect(summary.byCategory.accommodation).toBe(150000)
      expect(summary.byCategory.food).toBe(80000)
      expect(summary.byCategory.transport).toBe(100000)
    })

    it("should detect over budget situation", () => {
      const overBudgetItems = [
        ...mockBudgetItems,
        {
          id: "budget-4",
          planId: "plan-1",
          category: "shopping",
          amount: 300000,
          description: "쇼핑",
          date: new Date("2024-03-16"),
        },
      ]

      const summary = service.calculateBudgetSummary(mockPlan, overBudgetItems)

      expect(summary.total).toBe(630000)
      expect(summary.remaining).toBe(-130000)
      expect(summary.overBudget).toBe(true)
    })

    it("should group expenses by day", () => {
      const multiDayItems = [
        ...mockBudgetItems,
        {
          id: "budget-4",
          planId: "plan-1",
          category: "food",
          amount: 60000,
          description: "둘째날 식비",
          date: new Date("2024-03-16"),
        },
      ]

      const summary = service.calculateBudgetSummary(mockPlan, multiDayItems)

      expect(summary.byDay).toHaveLength(2)
      expect(summary.byDay[0]).toEqual({
        date: "2024-03-15",
        amount: 330000,
      })
      expect(summary.byDay[1]).toEqual({
        date: "2024-03-16",
        amount: 60000,
      })
    })
  })

  describe("generateRecommendations", () => {
    it("should generate recommendations for unbalanced budget", () => {
      // Create unbalanced budget (too much on accommodation)
      const unbalancedItems = [
        {
          id: "budget-1",
          planId: "plan-1",
          category: "accommodation" as const,
          amount: 400000, // 80% of budget
          description: "고급 호텔",
          date: new Date("2024-03-15"),
        },
      ]

      const recommendations = service.generateRecommendations(mockPlan, unbalancedItems)

      expect(recommendations).toHaveLength(1)
      expect(recommendations[0].category).toBe("accommodation")
      expect(recommendations[0].currentAmount).toBe(400000)
      expect(recommendations[0].reason).toContain("권장 금액보다 높습니다")
    })

    it("should not generate recommendations for balanced budget", () => {
      const recommendations = service.generateRecommendations(mockPlan, mockBudgetItems)

      // Should have minimal recommendations for reasonably balanced budget
      expect(recommendations.length).toBeLessThanOrEqual(2)
    })
  })

  describe("optimizeBudget", () => {
    it("should optimize over-budget items", () => {
      const overBudgetItems = [
        {
          id: "budget-1",
          planId: "plan-1",
          category: "shopping" as const,
          amount: 300000,
          description: "쇼핑",
          date: new Date("2024-03-15"),
        },
        {
          id: "budget-2",
          planId: "plan-1",
          category: "accommodation" as const,
          amount: 300000,
          description: "숙박",
          date: new Date("2024-03-15"),
        },
      ]

      const optimized = service.optimizeBudget(mockPlan, overBudgetItems)
      const totalOptimized = optimized.reduce((sum, item) => sum + item.amount, 0)

      expect(totalOptimized).toBeLessThan(600000) // Should be reduced
      expect(totalOptimized).toBeGreaterThan(500000) // But not below budget
    })

    it("should not modify budget within limits", () => {
      const optimized = service.optimizeBudget(mockPlan, mockBudgetItems)
      const originalTotal = mockBudgetItems.reduce((sum, item) => sum + item.amount, 0)
      const optimizedTotal = optimized.reduce((sum, item) => sum + item.amount, 0)

      expect(optimizedTotal).toBe(originalTotal) // Should remain unchanged
    })
  })

  describe("mapPOICategoryToBudgetCategory", () => {
    it("should map POI categories to budget categories correctly", () => {
      expect((service as any).mapPOICategoryToBudgetCategory("attraction")).toBe("attraction")
      expect((service as any).mapPOICategoryToBudgetCategory("restaurant")).toBe("food")
      expect((service as any).mapPOICategoryToBudgetCategory("accommodation")).toBe("accommodation")
      expect((service as any).mapPOICategoryToBudgetCategory("shopping")).toBe("shopping")
      expect((service as any).mapPOICategoryToBudgetCategory("transport")).toBe("transport")
      expect((service as any).mapPOICategoryToBudgetCategory("unknown")).toBe("other")
    })
  })
})
