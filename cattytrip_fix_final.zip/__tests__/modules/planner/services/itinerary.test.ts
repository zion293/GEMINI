import { ItineraryService } from "@/modules/planner/services/itinerary"
import type { ItineraryInput, ItineraryConstraints } from "@/modules/planner/services/itinerary"
import jest from "jest" // Declare the jest variable

// Mock external dependencies
jest.mock("@/core/lib/map", () => ({
  searchPlaces: jest.fn(),
  calculateDistance: jest.fn(() => Promise.resolve(1000)),
}))

jest.mock("@/core/lib/weather", () => ({
  getCurrentWeather: jest.fn(() =>
    Promise.resolve({
      temperature: 20,
      condition: "clear",
      precipitation: 0,
    }),
  ),
}))

describe("ItineraryService", () => {
  let service: ItineraryService
  let mockInput: ItineraryInput
  let mockConstraints: ItineraryConstraints

  beforeEach(() => {
    service = new ItineraryService()

    mockInput = {
      destination: "제주도",
      startDate: new Date("2024-03-15"),
      endDate: new Date("2024-03-17"),
      budget: 500000,
      participants: 2,
      interests: ["nature", "food"],
      travelStyle: ["relaxation"],
    }

    mockConstraints = {
      maxDailyDistance: 50000,
      preferredTransportMode: "driving",
      budgetPerDay: 150000,
      startTime: "09:00",
      endTime: "18:00",
    }
  })

  describe("generateItinerary", () => {
    it("should generate a valid itinerary", async () => {
      const { searchPlaces } = require("@/core/lib/map")
      searchPlaces.mockResolvedValue([
        {
          place_id: "place1",
          name: "한라산",
          types: ["tourist_attraction"],
          geometry: {
            location: {
              lat: () => 33.3617,
              lng: () => 126.5292,
            },
          },
          formatted_address: "제주특별자치도 제주시",
          rating: 4.5,
          price_level: 2,
        },
      ])

      const result = await service.generateItinerary(mockInput, mockConstraints)

      expect(result).toBeDefined()
      expect(result.destination).toBe("제주도")
      expect(result.startDate).toEqual(mockInput.startDate)
      expect(result.endDate).toEqual(mockInput.endDate)
      expect(result.budget).toBe(mockInput.budget)
      expect(result.days).toHaveLength(3) // 3 days trip
    })

    it("should handle empty search results", async () => {
      const { searchPlaces } = require("@/core/lib/map")
      searchPlaces.mockResolvedValue([])

      const result = await service.generateItinerary(mockInput, mockConstraints)

      expect(result).toBeDefined()
      expect(result.days).toHaveLength(3)
      // Should still create days even with no POIs
      result.days.forEach((day) => {
        expect(day.slots).toHaveLength(0)
      })
    })

    it("should throw error on invalid input", async () => {
      const invalidInput = { ...mockInput, destination: "" }

      await expect(service.generateItinerary(invalidInput, mockConstraints)).rejects.toThrow()
    })
  })

  describe("buildSearchQueries", () => {
    it("should build appropriate search queries", () => {
      const queries = (service as any).buildSearchQueries(mockInput)

      expect(queries).toContain("제주도 관광지")
      expect(queries).toContain("제주도 명소")
      expect(queries).toContain("제주도 nature")
      expect(queries).toContain("제주도 food")
    })
  })

  describe("categorizePlace", () => {
    it("should categorize places correctly", () => {
      const attractionPlace = { types: ["tourist_attraction"] }
      const restaurantPlace = { types: ["restaurant"] }
      const hotelPlace = { types: ["lodging"] }

      expect((service as any).categorizePlace(attractionPlace)).toBe("attraction")
      expect((service as any).categorizePlace(restaurantPlace)).toBe("restaurant")
      expect((service as any).categorizePlace(hotelPlace)).toBe("accommodation")
    })

    it('should default to "other" for unknown types', () => {
      const unknownPlace = { types: ["unknown_type"] }
      expect((service as any).categorizePlace(unknownPlace)).toBe("other")
    })
  })

  describe("estimateVisitDuration", () => {
    it("should estimate duration based on POI category", () => {
      const attractionPOI = { category: "attraction" } as any
      const restaurantPOI = { category: "restaurant" } as any
      const shoppingPOI = { category: "shopping" } as any

      expect((service as any).estimateVisitDuration(attractionPOI)).toBe(2)
      expect((service as any).estimateVisitDuration(restaurantPOI)).toBe(1.5)
      expect((service as any).estimateVisitDuration(shoppingPOI)).toBe(1)
    })
  })
})
