# CattyTrip 로컬 실행 가이드 (pnpm 버전)

## 1. Node.js 설치
- [Node.js 공식 사이트](https://nodejs.org)에서 LTS 버전 설치

## 2. pnpm 설치
```bash
npm install -g pnpm
```

## 3. 의존성 설치
```bash
pnpm install
```

## 4. 로컬 개발 서버 실행
```bash
pnpm dev
```

## 5. 브라우저 접속
- 기본 주소: http://localhost:3000

## 참고
- 에러 발생 시 터미널 로그를 확인하고, 환경 변수(.env) 세팅 필요 여부를 체크하세요.
