"use client"

import { useEffect, useState } from "react"
import type { ApiResult } from "@/core/lib/fetcher"
import { fetcher } from "@/core/lib/fetcher"

export function useQuery<T>(path: string, deps: any[] = []) {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    setLoading(true)
    fetcher<T>(path).then((res: ApiResult<T>) => {
      if (cancelled) return
      if (res.ok) setData(res.data)
      else setError(res.error)
      setLoading(false)
    })
    return () => {
      cancelled = true
    }
  }, deps)

  return { data, loading, error }
}
