import { create } from "zustand"

interface Destination {
  id: string
  name: string
  lat: number
  lng: number
  category: string
  description?: string
}

interface TripPlan {
  id: string
  title: string
  destinations: Destination[]
  budget: number
  duration: number
  interests: string[]
}

interface ChatMessage {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
  functionCall?: any
}

interface AppState {
  // Map state
  destinations: Destination[]
  highlightedPlaceId: string | null

  // Trip planning state
  currentTrip: TripPlan | null

  // Chat state
  messages: ChatMessage[]
  isAiTyping: boolean

  // User location
  userLocation: { lat: number; lng: number } | null

  // Actions
  setDestinations: (destinations: Destination[]) => void
  setHighlightedPlace: (placeId: string | null) => void
  setCurrentTrip: (trip: TripPlan | null) => void
  addMessage: (message: ChatMessage) => void
  setAiTyping: (typing: boolean) => void
  setUserLocation: (location: { lat: number; lng: number } | null) => void
}

export const useAppStore = create<AppState>((set) => ({
  destinations: [],
  highlightedPlaceId: null,
  currentTrip: null,
  messages: [],
  isAiTyping: false,
  userLocation: null,

  setDestinations: (destinations) => set({ destinations }),
  setHighlightedPlace: (placeId) => set({ highlightedPlaceId: placeId }),
  setCurrentTrip: (trip) => set({ currentTrip: trip }),
  addMessage: (message) =>
    set((state) => ({
      messages: [...state.messages, message],
    })),
  setAiTyping: (typing) => set({ isAiTyping: typing }),
  setUserLocation: (location) => set({ userLocation: location }),
}))
