// middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';

const GUEST_WHITELIST = [
  '/planner', '/explore', '/deals',
  '/api/search', '/api/search/pois',
  '/api/deals',
];

export async function middleware(req: NextRequest) {
  // guestId 발급
  if (!req.cookies.get('guestId')) {
    const res = NextResponse.next();
    res.cookies.set('guestId', crypto.randomUUID(), { httpOnly: true, path: '/', sameSite: 'lax', maxAge: 60*60*24*365 });
    return res;
  }

  const { pathname } = req.nextUrl;
  const isWhitelisted = GUEST_WHITELIST.some(p => pathname === p || pathname.startsWith(p+'/'));
  const isApp = pathname.startsWith('/app');

  if (isApp && !isWhitelisted) {
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    if (!token) {
      const url = new URL('/auth/sign-in', req.url);
      url.searchParams.set('next', pathname);
      return NextResponse.redirect(url);
    }
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
