'use client';
import { useState } from 'react';

export default function SignInPage(){
  const [show, setShow] = useState(false);

  return (
    <main>
      <h1>Sign In</h1>
      <form aria-label="sign-in-form">
        <label>
          Email
          <input name="email" type="email" placeholder="you@example.com" required />
        </label>
        <label>
          Password
          <input name="password" type={show ? 'text' : 'password'} placeholder="••••••••" required />
        </label>
        <button type="submit">로그인</button>
        <button type="button" onClick={()=>setShow(s=>!s)} aria-label="toggle-password">
          비밀번호 표시 전환
        </button>
      </form>

      <div aria-label="social-login">
        <button>Sign in with Google</button>
        <button>Continue as Guest</button>
      </div>

      <button type="button" aria-label="switch-to-sign-up">회원가입으로 전환</button>
    </main>
  );
}
