import type React from "react"
import AppNav from "@/components/AppNav"

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-dvh bg-gray-50">
      <aside className="hidden w-64 border-r bg-white p-4 md:block">
        <div className="mb-4 text-lg font-bold">CattyTrip</div>
        <AppNav />
      </aside>
      <div className="flex-1">
        <div className="sticky top-0 z-20 border-b bg-white/90 backdrop-blur">
          <div className="mx-auto flex h-12 max-w-6xl items-center justify-between px-4">
            <div className="md:hidden">
              {/* 모바일 메뉴 버튼 (추후) */}
              <span className="text-sm text-gray-500">메뉴</span>
            </div>
            <div className="text-sm text-gray-600">로그인 영역(사용자 메뉴)</div>
          </div>
        </div>
        <main className="mx-auto max-w-6xl p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}
