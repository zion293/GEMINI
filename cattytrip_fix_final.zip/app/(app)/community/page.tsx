export default function CommunityPage() {
  const posts = [
    { id: "p1", title: "오사카 2박3일 플랜 공유", meta: "추천 12 · 댓글 4" },
    { id: "p2", title: "제주 동부 코스(비수기 버전)", meta: "추천 7 · 댓글 1" },
  ]
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">계획 공유/피드</h2>
      <div className="space-y-3">
        {posts.map(p => (
          <div key={p.id} className="rounded-2xl border bg-white p-5 shadow-sm">
            <div className="font-medium">{p.title}</div>
            <div className="text-xs text-gray-500">{p.meta}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
