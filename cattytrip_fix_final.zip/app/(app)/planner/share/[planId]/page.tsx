type Props = { params: { planId: string } };

type Plan = {
  id: string;
  title: string;
  days?: Array<{ date: string; items: Array<{ time?: string; name: string }> }>;
};

async function getPlan(id: string): Promise<Plan | null> {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL ?? ""}/api/plans/${id}`, { next: { revalidate: 30 } });
  if (!res.ok) return null;
  return res.json();
}

export default async function PlanSharePage({ params }: Props) {
  const plan = await getPlan(params.planId);

  if (!plan) {
    return <div className="p-6">공유용 플랜을 불러오지 못했습니다.</div>;
  }

  return (
    <div className="mx-auto max-w-3xl p-6">
      <h2 className="mb-2 text-2xl font-semibold">{plan.title ?? "공유 플랜"}</h2>
      <div className="mb-6 text-gray-500">공유 ID: {plan.id}</div>

      <div className="space-y-4">
        {(plan.days ?? []).map((d, i) => (
          <div key={i} className="rounded-2xl bg-white p-4 shadow">
            <div className="mb-2 font-medium">{d.date}</div>
            <ul className="space-y-1 text-sm text-gray-700">
              {d.items.map((it, idx) => (
                <li key={idx}>{it.time ? `[${it.time}] ` : ""}{it.name}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
