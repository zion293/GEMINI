import Link from "next/link";

type Plan = {
  id: string;
  title: string;
  updatedAt?: string;
};

async function getPlans(): Promise<Plan[]> {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL ?? ""}/api/plans`, {
    cache: "no-store",
  });
  if (!res.ok) {
    return [];
  }
  return res.json();
}

export default async function PlannerHomePage() {
  const plans = await getPlans();

  return (
    <div className="mx-auto max-w-5xl p-6">
      <h2 className="mb-4 text-2xl font-semibold">여행 계획 메인</h2>
      <p className="mb-6 text-gray-600">내 플랜 목록입니다. 편집/공유로 이동하세요.</p>

      <div className="rounded-2xl bg-white p-4 shadow">
        {plans.length === 0 ? (
          <div className="text-sm text-gray-500">아직 플랜이 없습니다. 우측 상단에서 새 플랜을 만들어 보세요.</div>
        ) : (
          <ul className="divide-y">
            {plans.map((p) => (
              <li key={p.id} className="flex items-center justify-between py-3">
                <div>
                  <div className="font-medium">{p.title ?? `플랜 ${p.id}`}</div>
                  <div className="text-xs text-gray-500">{p.updatedAt ? `업데이트: ${new Date(p.updatedAt).toLocaleString()}` : ""}</div>
                </div>
                <div className="flex gap-2">
                  <Link href={`/app/planner/edit/${p.id}`} className="rounded-lg border px-3 py-1.5 text-sm">편집</Link>
                  <Link href={`/app/planner/share/${p.id}`} className="rounded-lg border px-3 py-1.5 text-sm">공유 보기</Link>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
