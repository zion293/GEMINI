// 'use server'
export async function createPlanAction(formData: FormData) {
  // TODO: implement with BFF
  return { ok: true, data: { id: "tmp", title: formData.get("title") ?? "새 플랜" } }
}
