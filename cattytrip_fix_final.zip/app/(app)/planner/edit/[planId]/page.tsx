type Props = { params: { planId: string } };

type Plan = {
  id: string;
  title: string;
  days?: Array<{ date: string; items: Array<{ time?: string; name: string }> }>;
};

async function getPlan(id: string): Promise<Plan | null> {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL ?? ""}/api/plans/${id}`, { cache: "no-store" });
  if (!res.ok) return null;
  return res.json();
}

export default async function PlanEditPage({ params }: Props) {
  const plan = await getPlan(params.planId);

  if (!plan) {
    return <div className="p-6">플랜을 찾을 수 없습니다.</div>;
  }

  return (
    <div className="mx-auto max-w-5xl p-6">
      <h2 className="mb-2 text-2xl font-semibold">플랜 편집</h2>
      <div className="mb-6 text-gray-600">ID: {plan.id}</div>

      <div className="rounded-2xl bg-white p-4 shadow">
        <div className="mb-4">
          <label className="block text-sm text-gray-600">제목</label>
          <input defaultValue={plan.title} className="mt-1 w-full rounded-lg border px-3 py-2" />
        </div>

        <div className="space-y-4">
          {(plan.days ?? []).map((d, i) => (
            <div key={i} className="rounded-lg border p-3">
              <div className="mb-2 text-sm font-medium">{d.date}</div>
              <ul className="space-y-2">
                {d.items.map((it, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm">
                    <input defaultValue={it.time ?? ""} placeholder="시간" className="w-20 rounded border px-2 py-1" />
                    <input defaultValue={it.name} className="flex-1 rounded border px-2 py-1" />
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-6 flex gap-2">
          <button className="rounded-lg bg-black px-4 py-2 text-white">임시 저장</button>
          <a href={`/app/planner/share/${plan.id}`} className="rounded-lg border px-4 py-2">공유 보기</a>
        </div>
      </div>
    </div>
  );
}
