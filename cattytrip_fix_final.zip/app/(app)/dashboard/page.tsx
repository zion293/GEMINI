export default function DashboardPage() {
  const cards = [
    { title: "내 플랜", value: "3개", desc: "최근 30일 생성" },
    { title: "총 예산", value: "₩1,240,000", desc: "예상 합계" },
    { title: "공유 플랜", value: "2개", desc: "친구와 공유 중" },
  ]
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">대시보드</h2>
      <div className="grid gap-4 md:grid-cols-3">
        {cards.map(c => (
          <div key={c.title} className="rounded-2xl border bg-white p-6 shadow-sm">
            <div className="text-sm text-gray-500">{c.title}</div>
            <div className="mt-1 text-xl font-semibold">{c.value}</div>
            <div className="text-xs text-gray-500">{c.desc}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
