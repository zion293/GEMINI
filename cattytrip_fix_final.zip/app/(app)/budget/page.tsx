export default function BudgetPage() {
  const cats = [
    { name: "항공", amount: 620000 },
    { name: "숙소", amount: 380000 },
    { name: "식비", amount: 140000 },
    { name: "교통", amount: 60000 },
  ]
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold">예산/지출 요약</h2>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {cats.map(c => (
          <div key={c.name} className="rounded-2xl border bg-white p-6 shadow-sm">
            <div className="text-sm text-gray-500">{c.name}</div>
            <div className="mt-1 text-xl font-semibold">₩{c.amount.toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
