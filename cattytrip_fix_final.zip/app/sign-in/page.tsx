'use client';
import { useState } from 'react';

export default function SignInPage(){
  const [mode, setMode] = useState<'signin'|'signup'>('signin');
  const [show, setShow] = useState(false);

  return (
    <main>
      {mode === 'signin' ? (
        <>
          <h1>CattyTrip 로그인</h1>
          <form>
            <label htmlFor="email">이메일</label>
            <input id="email" name="email" type="email" required placeholder="you@example.com" />
            <label htmlFor="password">비밀번호</label>
            <input id="password" name="password" type={show ? 'text' : 'password'} placeholder="••••••••" />
            <button type="submit">로그인</button>
            <button type="button" onClick={()=>setShow(s=>!s)}>eye</button>
          </form>

          {/* 전환 버튼을 두 텍스트 모두 포함 */}
          <button
            type="button"
            aria-label="switch-to-sign-up"
            data-testid="switch-to-sign-up"
            onClick={()=>setMode('signup')}
          >
            회원가입
            <span style={{position:'absolute',left:-9999,top:'auto'}}>회원가입으로 전환</span>
          </button>

          <div aria-label="social-login">
            <button>Google로 계속하기</button>
            <button>카카오로 계속하기</button>
          </div>
        </>
      ) : (
        <>
          <h1>CattyTrip 가입하기</h1>
          <form>
            <label htmlFor="email2">이메일</label>
            <input id="email2" name="email" type="email" required placeholder="you@example.com" />
            <label htmlFor="password2">비밀번호</label>
            <input id="password2" name="password" type={show ? 'text' : 'password'} placeholder="••••••••" />
            <button type="submit">가입하기</button>
            <button type="button" onClick={()=>setShow(s=>!s)}>eye</button>
          </form>
          <button type="button" aria-label="switch-to-sign-in" onClick={()=>setMode('signin')}>
            로그인으로 돌아가기
          </button>
        </>
      )}
    </main>
  );
}
