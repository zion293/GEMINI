import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "비수기·특가 큐레이션 | CattyTrip",
};

type Deal = {
  id: string;
  title: string;
  subtitle?: string;
  price?: number;
  currency?: string;
  badge?: string;
  url?: string;
};

async function getDeals(): Promise<Deal[]> {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL ?? ""}/api/deals`, {
      next: { revalidate: 60 },
    });
    if (!res.ok) throw new Error("Failed");
    return await res.json();
  } catch {
    return [
      { id: "mock-1", title: "오사카 평일 특가", subtitle: "10~12월 비수기", price: 119000, currency: "KRW", badge: "비수기" },
      { id: "mock-2", title: "제주 주중 호텔", subtitle: "조식 포함", price: 69000, currency: "KRW", badge: "특가" },
      { id: "mock-3", title: "타이페이 왕복", subtitle: "주중 한정", price: 179000, currency: "KRW", badge: "항공" },
    ];
  }
}

export default async function DealsPage() {
  const deals = await getDeals();

  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">비수기·특가 큐레이션</h2>
      <p className="text-gray-600">항공/숙소가 저렴한 시즌과 이벤트형 여행을 모아 보여줘요.</p>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {deals.map((d) => (
          <a key={d.id} href={d.url ?? "#"} className="rounded-2xl border bg-white p-5 shadow-sm transition hover:shadow-md">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs rounded-full border px-2 py-0.5">{d.badge ?? "추천"}</span>
              {typeof d.price === "number" && (
                <span className="text-sm font-semibold">
                  {d.price.toLocaleString()} {d.currency ?? "KRW"}
                </span>
              )}
            </div>
            <div className="text-base font-medium">{d.title}</div>
            {d.subtitle && <div className="text-sm text-gray-500">{d.subtitle}</div>}
          </a>
        ))}
      </div>
    </div>
  );
}
