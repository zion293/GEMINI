import type React from "react"
import Link from "next/link"
import PublicNav from "@/components/PublicNav"

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh bg-gradient-to-b from-white to-blue-50/40 text-gray-900">
      <header className="sticky top-0 z-30 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/90 border-b">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
          <Link href="/" className="text-base font-bold tracking-tight">CattyTrip</Link>
          <PublicNav />
          <div className="hidden sm:block">
            <Link href="/sign-in" className="rounded-lg border px-3 py-1.5 text-sm hover:bg-gray-50">로그인</Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {children}
      </main>

      <footer className="mt-16 border-t">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-6 text-sm text-gray-500">
          <span>© {new Date().getFullYear()} CattyTrip</span>
          <nav className="space-x-4">
            <Link href="/explore" className="hover:underline">탐색</Link>
            <Link href="/deals" className="hover:underline">비수기·특가</Link>
            <a href="https://example.com" className="hover:underline">문의</a>
          </nav>
        </div>
      </footer>
    </div>
  )
}
