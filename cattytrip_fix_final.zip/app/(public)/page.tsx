export default function LandingPage() {
  return (
    <main>
      <section aria-label="hero">
        <h1>AI와 함께하는 스마트 여행 계획</h1>
        <p>복잡한 여행 계획을 AI가 도와드립니다</p>
        <nav>
          <a href="/sign-in">AI와 함께 여행 계획 시작하기</a>
          {' '}
          <a href="/explore">여행지 둘러보기</a>
          {' '}
          <a href="/explore">지금 탐색하기</a>
          {' '}
          <a href="/sign-in">로그인</a>
        </nav>
      </section>
      <section aria-label="features">
        <ul>
          <li>AI 맞춤 추천</li>
          <li>실시간 지도</li>
          <li>스마트 일정</li>
          <li>커뮤니티</li>
        </ul>
      </section>
    </main>
  );
}
