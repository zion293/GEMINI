'use client';
import { useState } from 'react';

type Card = {
  id: string;
  title: string;
  description: string;
  days: string;
  budget: string;
  tags: string[];
};

const cards: Card[] = [
  { id: 'jeju', title: '제주도', description: '아름다운 자연과 독특한 문화가 어우러진 섬', days: '2-3일', budget: '15-25만원', tags: ['자연','힐링','드라이브'] },
  { id: 'busan', title: '부산', description: '바다와 도시가 공존하는 활기찬 항구도시', days: '1-2일', budget: '10-20만원', tags: ['해변','미식','카페'] },
  { id: 'gyeongju', title: '경주', description: '역사와 문화가 살아 숨쉬는 천년고도', days: '1-2일', budget: '8-18만원', tags: ['역사','유적','포토'] },
];

export default function ExplorePage(){
  const [selected, setSelected] = useState<Card | null>(null);
  return (
    <main>
      <h1>여행지 탐색</h1>
      <div role="list" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {cards.map((c) => (
          <article key={c.id} role="listitem">
            <button
              type="button"
              role="button"
              data-testid="destination-card"
              aria-label={`${c.title} 카드`}
              onClick={() => setSelected(c)}
              style={{ width: '100%', textAlign: 'left', border: '1px solid #eee', padding: 12, borderRadius: 8, cursor: 'pointer' }}
            >
              <h2>{c.title}</h2>
              <p>{c.description}</p>
              <ul style={{ marginTop: 8 }}>
                <li>{c.days}</li>
                <li>{c.budget}</li>
              </ul>
              <div style={{ display: 'flex', gap: 6, marginTop: 6, flexWrap: 'wrap' }}>
                {c.tags.map((t) => (
                  <span key={t} style={{ border: '1px solid #ddd', borderRadius: 12, padding: '2px 8px' }}>{t}</span>
                ))}
              </div>
            </button>
          </article>
        ))}
      </div>
      {selected && (
        <section
          role="region"
          aria-label="destination details"
          data-testid="destination-details"
          style={{ marginTop: 16, borderTop: '1px solid #ddd', paddingTop: 12 }}
        >
          <h3>{selected.title}</h3>
          <p>{selected.description}</p>
          <ul>
            <li>{selected.days}</li>
            <li>{selected.budget}</li>
            {selected.tags.map((t) => <li key={t}>{t}</li>)}
          </ul>
        </section>
      )}
    </main>
  );
}
