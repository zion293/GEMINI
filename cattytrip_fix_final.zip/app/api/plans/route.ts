import { NextRequest, NextResponse } from 'next/server';
const mem: Map<string, any> = (globalThis as any).__PLANS__ || new Map(); (globalThis as any).__PLANS__ = mem;
export async function GET(){ return NextResponse.json({ ok: true, data: Array.from(mem.values()) }); }
export async function POST(req: NextRequest){ const body = await req.json().catch(()=>({})); const id = `p_${Date.now()}`; mem.set(id, { id, ...body, createdAt: new Date().toISOString() }); return NextResponse.json({ ok: true, data: { id } }, { status: 201 }); }
