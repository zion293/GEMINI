// app/api/search/pois/route.ts
import { NextRequest } from 'next/server';
import { ok, fail } from '@/core/lib/fetcher';
import { searchQuerySchema } from '@/schemas/search.schema';
import { searchPois } from '@/modules/search/services/search';

export async function GET(req: NextRequest) {
  try {
    const parsed = searchQuerySchema.parse(Object.fromEntries(req.nextUrl.searchParams));
    const data = await searchPois(parsed);
    return Response.json(ok(data));
  } catch (e:any) {
    return fail(e?.message ?? 'INVALID_QUERY', 400);
  }
}
