import { type NextRequest, NextResponse } from "next/server"
import { logger } from "@/core/lib/logger"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")
    const limit = Number.parseInt(searchParams.get("limit") || "5")

    if (!query || query.length < 2) {
      return NextResponse.json({ suggestions: [] })
    }

    // TODO: 실제 검색 제안 로직 (데이터베이스 또는 검색 엔진)
    const mockSuggestions = [
      `${query} 맛집`,
      `${query} 관광지`,
      `${query} 카페`,
      `${query} 숙박`,
      `${query} 쇼핑`,
    ].slice(0, limit)

    logger.info("Search suggestions generated", { query, count: mockSuggestions.length })

    return NextResponse.json(
      { suggestions: mockSuggestions },
      {
        headers: {
          "Cache-Control": "s-maxage=3600, stale-while-revalidate=7200",
        },
      },
    )
  } catch (error) {
    logger.error("Failed to generate suggestions", {}, error as Error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
