// app/api/auth/[...nextauth]/route.ts
import NextAuth from 'next-auth';
import Google from 'next-auth/providers/google';
import Credentials from 'next-auth/providers/credentials';

export const authOptions = {
  session: { strategy: 'jwt' as const },
  providers: [
    Google({
      clientId: process.env.GOOGLE_ID ?? '',
      clientSecret: process.env.GOOGLE_SECRET ?? '',
    }),
    Credentials({
      name: 'GuestLink',
      credentials: { guestId: { label: 'guestId', type: 'text' } },
      async authorize(creds) {
        if (creds?.guestId) return { id: `guest:${creds.guestId}`, name: 'Guest' };
        return null;
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }: any) {
      if (user?.id) token.uid = user.id;
      return token;
    },
    async session({ session, token }: any) {
      (session as any).uid = token.uid;
      return session;
    },
  },
  pages: {},
  trustHost: true,
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
