import { type NextRequest, NextResponse } from "next/server"
import { logger } from "@/core/lib/logger"
import type { User } from "@/core/types/user"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    // TODO: 실제 인증 로직 (데이터베이스 확인, 비밀번호 해시 검증)
    const user: User = {
      id: crypto.randomUUID(),
      email,
      name: "Test User",
      level: 1,
      xp: 0,
      badges: [],
      preferences: {
        currency: "KRW",
        language: "ko",
        travelStyle: ["cultural"],
        budgetRange: { min: 100000, max: 500000, currency: "KRW" },
        interests: ["food", "history"],
      },
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    // TODO: JWT 토큰 생성
    const token = "mock-jwt-token"

    logger.info("User logged in", { userId: user.id, email })

    const response = NextResponse.json({ user, token })

    // Set HTTP-only cookie
    response.cookies.set("auth-token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 7 * 24 * 60 * 60, // 7 days
    })

    return response
  } catch (error) {
    logger.error("Login failed", {}, error as Error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
