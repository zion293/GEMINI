import { type NextRequest, NextResponse } from "next/server"
import { logger } from "@/core/lib/logger"

export async function POST(request: NextRequest) {
  try {
    logger.info("User logged out")

    const response = NextResponse.json({ success: true })

    // Clear auth cookie
    response.cookies.delete("auth-token")

    return response
  } catch (error) {
    logger.error("Logout failed", {}, error as Error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
