export default function PlannerPage(){
  return (
    <main>
      <h1>플래너</h1>
      <p data-testid="guest-mode-banner">게스트 모드: 저장된 계획은 브라우저에 임시 저장됩니다.</p>
    </main>
  );
}
