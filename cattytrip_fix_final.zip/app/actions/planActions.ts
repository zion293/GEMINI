// app/actions/planActions.ts
'use server';
import { withZod } from './_util';
import { planCreateSchema, planUpdateSchema } from '@/schemas/plan.schema';
import { inMemoryPlans } from '@/core/lib/inmemory';

export const createPlanAction = (dto: unknown) =>
  withZod(planCreateSchema, async (input) => {
    const id = `p_${Date.now()}`;
    inMemoryPlans.set(id, { id, ...input, createdAt: new Date().toISOString() });
    return { id };
  });

export const updatePlanAction = (dto: unknown) =>
  withZod(planUpdateSchema, async (input) => {
    const exists = inMemoryPlans.get(input.id);
    if (!exists) throw new Error('NOT_FOUND');
    inMemoryPlans.set(input.id, { ...exists, ...input });
    return { id: input.id };
  });
