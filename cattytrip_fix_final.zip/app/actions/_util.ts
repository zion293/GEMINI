// app/actions/_util.ts
'use server';
import { z, ZodSchema } from 'zod';

export type ActionResponse<T> = { ok:true; data:T } | { ok:false; error:string };

export async function withZod<TSchema extends ZodSchema, TResult>(
  schema: TSchema,
  fn: (input: z.infer<TSchema>) => Promise<TResult>
): Promise<ActionResponse<TResult>> {
  try {
    const input = schema.parse(arguments[0]);
    const data = await fn(input as any);
    return { ok: true, data };
  } catch (e:any) {
    return { ok:false, error: e?.message ?? 'INVALID_INPUT' };
  }
}
