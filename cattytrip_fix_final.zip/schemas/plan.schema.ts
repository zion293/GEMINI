// schemas/plan.schema.ts
import { z } from 'zod';

const poiSchema = z.object({
  id: z.string(),
  name: z.string(),
  category: z.enum(['RESTAURANT','MUSEUM','LANDMARK','SHOPPING','OTHER']).optional(),
  location: z.object({ lat: z.number(), lng: z.number() }),
  popularityScore: z.number().min(0).max(1).optional(),
});

const dayStopSchema = z.object({
  poi: poiSchema,
  start: z.string().datetime(),
  durationMinutes: z.number().int().min(5).max(12*60),
  travelMode: z.enum(['WALK','BIKE','CAR','TRANSIT']).optional(),
  openHours: z.object({
    days: z.array(z.number().int().min(1).max(7)),
    open: z.string().regex(/^\d{2}:\d{2}$/),
    close: z.string().regex(/^\d{2}:\d{2}$/),
    timezone: z.string().optional(),
  }).optional(),
  preferenceScore: z.number().min(0).max(1).optional(),
});

export const planDaySchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  timezone: z.string().optional(),
  stops: z.array(dayStopSchema).min(1),
});

export const planCreateSchema = z.object({
  title: z.string().min(1),
  days: z.array(planDaySchema).min(1),
});

export const planUpdateSchema = z.object({
  id: z.string(),
  title: z.string().min(1).optional(),
  days: z.array(planDaySchema).min(1).optional(),
});
