// schemas/deals.schema.ts
import { z } from 'zod';

export const dealsQueryBase = {
  region: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  types: z.preprocess(v => Array.isArray(v) ? v : (typeof v==='string' ? v.split(',') : undefined),
    z.array(z.enum(['FLIGHT','HOTEL','EVENT'])).optional()),
};

export const dealsQuerySchema = z.object(dealsQueryBase);
