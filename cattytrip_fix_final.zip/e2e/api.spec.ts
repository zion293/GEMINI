import { test, expect } from '@playwright/test';

test('GET /api/deals returns {ok,data}', async ({ request }) => {
  const res = await request.get('/api/deals?region=JP-KIX&types=FLIGHT,HOTEL');
  expect(res.ok()).toBeTruthy();
  const body = await res.json();
  expect(body.ok).toBe(true);
  expect(Array.isArray(body.data)).toBe(true);
});

test('POST /api/plans create (in-memory)', async ({ request }) => {
  const payload = {
    title: '테스트 플랜',
    days: [{
      date: '2025-09-01',
      timezone: 'Asia/Seoul',
      stops: [{
        poi: { id:'p1', name:'난바역', location:{lat:34.666,lng:135.501}, category:'LANDMARK' },
        start: new Date().toISOString(),
        durationMinutes: 60,
        travelMode: 'TRANSIT'
      }]
    }]
  };
  const res = await request.post('/api/plans', { data: payload });
  const body = await res.json();
  expect(body.ok).toBe(true);
  expect(body.data.id).toBeTruthy();
});
