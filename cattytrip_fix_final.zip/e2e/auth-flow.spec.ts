import { test, expect } from "@playwright/test"

test.describe("Authentication Flow", () => {
  test("should display sign-in form by default", async ({ page }) => {
    await page.goto("/sign-in")

    await expect(page.getByRole("heading", { name: /CattyTrip 로그인/ })).toBeVisible()
    await expect(page.getByLabel("이메일")).toBeVisible()
    await expect(page.getByLabel("비밀번호")).toBeVisible()
    await expect(page.getByRole("button", { name: "로그인" })).toBeVisible()
  })

  test("should switch to sign-up form", async ({ page }) => {
    await page.goto("/sign-in")

    await page.getByRole("button", { name: "가입하기" }).click()

    await expect(page.getByRole("heading", { name: /CattyTrip 가입하기/ })).toBeVisible()
    await expect(page.getByLabel("이름")).toBeVisible()
    await expect(page.getByLabel("이메일")).toBeVisible()
    await expect(page.getByLabel("비밀번호")).toBeVisible()
    await expect(page.getByLabel("비밀번호 확인")).toBeVisible()
    await expect(page.getByRole("button", { name: "가입하기" })).toBeVisible()
  })

  test("should toggle password visibility", async ({ page }) => {
    await page.goto("/sign-in")

    const passwordInput = page.getByLabel("비밀번호")
    const toggleButton = page.locator('button[type="button"]').filter({ hasText: /eye/i }).first()

    // Initially password should be hidden
    await expect(passwordInput).toHaveAttribute("type", "password")

    // Click toggle to show password
    await toggleButton.click()
    await expect(passwordInput).toHaveAttribute("type", "text")

    // Click toggle to hide password again
    await toggleButton.click()
    await expect(passwordInput).toHaveAttribute("type", "password")
  })

  test("should show validation for empty form", async ({ page }) => {
    await page.goto("/sign-in")

    await page.getByRole("button", { name: "로그인" }).click()

    // HTML5 validation should prevent submission
    const emailInput = page.getByLabel("이메일")
    await expect(emailInput).toHaveAttribute("required")
  })

  test("should display social login options", async ({ page }) => {
    await page.goto("/sign-in")

    await expect(page.getByRole("button", { name: /Google로 계속하기/ })).toBeVisible()
    await expect(page.getByRole("button", { name: /카카오로 계속하기/ })).toBeVisible()
  })
})
