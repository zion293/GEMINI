import { test, expect } from '@playwright/test';

test('게스트로 /planner 접속 시 안내 문구 노출', async ({ page }) => {
  await page.goto('/planner');
  await expect(page.getByText(/게스트 모드/)).toBeVisible();
});
