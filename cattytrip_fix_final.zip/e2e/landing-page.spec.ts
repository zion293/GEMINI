import { test, expect } from "@playwright/test"

test.describe("Landing Page", () => {
  test("should display main hero section", async ({ page }) => {
    await page.goto("/")

    // Check hero section
    await expect(page.getByRole("heading", { name: /AI와 함께하는 스마트 여행 계획/ })).toBeVisible()
    await expect(page.getByText(/복잡한 여행 계획을 AI가 도와드립니다/)).toBeVisible()

    // Check CTA button
    const ctaButton = page.getByRole("link", { name: /AI와 함께 여행 계획 시작하기/ })
    await expect(ctaButton).toBeVisible()
    await expect(ctaButton).toHaveAttribute("href", "/sign-in")
  })

  test("should display features section", async ({ page }) => {
    await page.goto("/")

    // Check features
    await expect(page.getByText("AI 맞춤 추천")).toBeVisible()
    await expect(page.getByText("실시간 지도")).toBeVisible()
    await expect(page.getByText("스마트 일정")).toBeVisible()
    await expect(page.getByText("커뮤니티")).toBeVisible()
  })

  test("should navigate to explore page", async ({ page }) => {
    await page.goto("/")

    await page.getByRole("link", { name: /여행지 둘러보기/ }).click()
    await expect(page).toHaveURL("/explore")
    await expect(page.getByRole("heading", { name: /여행지 탐색/ })).toBeVisible()
  })

  test("should navigate to sign-in page", async ({ page }) => {
    await page.goto("/")

    await page.getByRole("link", { name: /AI와 함께 여행 계획 시작하기/ }).click()
    await expect(page).toHaveURL("/sign-in")
  })
})
