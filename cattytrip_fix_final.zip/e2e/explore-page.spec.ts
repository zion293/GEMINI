import { test, expect } from "@playwright/test"

test.describe("Explore Page", () => {
  test("should display destination cards", async ({ page }) => {
    await page.goto("/explore")

    await expect(page.getByRole("heading", { name: /여행지 탐색/ })).toBeVisible()

    // Check for destination cards
    await expect(page.getByText("제주도")).toBeVisible()
    await expect(page.getByText("부산")).toBeVisible()
    await expect(page.getByText("경주")).toBeVisible()
  })

  test("should display destination details", async ({ page }) => {
    await page.goto("/explore")

    // Check destination card content
    const jejuCard = page.locator("div").filter({ hasText: "제주도" }).first()

    await expect(jejuCard.getByText("아름다운 자연과 독특한 문화가 어우러진 섬")).toBeVisible()
    await expect(jejuCard.getByText("2-3일")).toBeVisible()
    await expect(jejuCard.getByText("15-25만원")).toBeVisible()

    // Check tags
    await expect(jejuCard.getByText("자연")).toBeVisible()
    await expect(jejuCard.getByText("힐링")).toBeVisible()
    await expect(jejuCard.getByText("드라이브")).toBeVisible()
  })

  test("should be responsive on mobile", async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 }) // iPhone SE size
    await page.goto("/explore")

    await expect(page.getByRole("heading", { name: /여행지 탐색/ })).toBeVisible()

    // Cards should stack vertically on mobile
    const cards = page.locator('[data-testid="destination-card"]')
    if ((await cards.count()) > 0) {
      // Check that cards are stacked (not side by side)
      const firstCard = cards.first()
      const secondCard = cards.nth(1)

      const firstCardBox = await firstCard.boundingBox()
      const secondCardBox = await secondCard.boundingBox()

      if (firstCardBox && secondCardBox) {
        expect(secondCardBox.y).toBeGreaterThan(firstCardBox.y + firstCardBox.height - 10)
      }
    }
  })
})
