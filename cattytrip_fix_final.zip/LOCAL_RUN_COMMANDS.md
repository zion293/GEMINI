# 로컬 실행 & 검증 명령 모음

## 기본
pnpm install
pnpm dev

## 품질 게이트
pnpm typecheck
pnpm test
pnpm lint

## e2e (옵션)
pnpm e2e
