# 로컬 실행 가이드 (CattyTrip Styled 버전)

이 문서는 `cattytrip_styled.zip` 프로젝트를 로컬에서 실행하기 위한 단계별 안내입니다.

---

## 1. 프로젝트 압축 해제
다운로드 받은 `cattytrip_styled.zip` 파일을 원하는 디렉터리에 압축 해제하세요.

```bash
unzip cattytrip_styled.zip -d cattytrip
cd cattytrip
```

---

## 2. Node.js / pnpm 설치
- Node.js: **버전 18 이상** 권장 (LTS)
- 패키지 매니저: `pnpm` 사용 (없다면 아래 명령으로 설치)

```bash
npm install -g pnpm
```

---

## 3. 의존성 설치
```bash
pnpm install
```

---

## 4. 환경변수 설정 (.env.local)
API 호출 시 필요한 경우, 프로젝트 루트에 `.env.local` 파일을 만들고 필요한 변수를 입력하세요.

예시:
```env
NEXT_PUBLIC_BASE_URL=http://localhost:3000
```

`NEXT_PUBLIC_BASE_URL`를 설정하지 않으면, 기본값(`""`)으로 현재 호스트에서 API를 호출합니다.

---

## 5. 개발 서버 실행
```bash
pnpm dev
```

브라우저에서:
```
http://localhost:3000
```

---

## 6. 주요 페이지 경로
- `/` : 랜딩 페이지
- `/explore` : 탐색 허브
- `/deals` : 비수기·특가
- `/sign-in` : 로그인
- `/app/dashboard` : 대시보드
- `/app/planner` : 여행 계획
- `/app/budget` : 예산/지출
- `/app/community` : 커뮤니티

---

## 7. 빌드 및 배포
```bash
pnpm build
pnpm start
```

`pnpm build` 후에는 정적 파일이 `.next/` 폴더에 생성되며, `pnpm start`로 프로덕션 모드 서버를 실행할 수 있습니다.

---

## 8. 참고
- TailwindCSS가 이미 설정되어 있으며, 스타일 변경은 `app/globals.css` 또는 각 컴포넌트 파일에서 가능합니다.
- 페이지 로딩 스켈레톤은 `loading.tsx` 파일로 정의되어 있습니다.
