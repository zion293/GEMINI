import { jest } from "@jest/globals"
import "@testing-library/jest-dom"

// Mock Google Maps API
global.google = {
  maps: {
    Map: jest.fn(),
    Marker: jest.fn(),
    InfoWindow: jest.fn(),
    LatLng: jest.fn((lat, lng) => ({ lat: () => lat, lng: () => lng })),
    places: {
      PlacesService: jest.fn(),
      PlacesServiceStatus: {
        OK: "OK",
        ZERO_RESULTS: "ZERO_RESULTS",
        OVER_QUERY_LIMIT: "OVER_QUERY_LIMIT",
        REQUEST_DENIED: "REQUEST_DENIED",
        INVALID_REQUEST: "INVALID_REQUEST",
      },
    },
    geometry: {
      spherical: {
        computeDistanceBetween: jest.fn(() => 1000),
      },
    },
    SymbolPath: {
      CIRCLE: 0,
    },
  },
}

// Mock window.crypto
Object.defineProperty(global, "crypto", {
  value: {
    randomUUID: () => "mock-uuid-" + Math.random().toString(36).substr(2, 9),
  },
})

// Mock fetch
global.fetch = jest.fn()

// Mock next/navigation
jest.mock("next/navigation", () => ({
  useRouter: () => ({
    push: jest.fn(),
    replace: jest.fn(),
    back: jest.fn(),
  }),
  useSearchParams: () => new URLSearchParams(),
  usePathname: () => "/",
}))
